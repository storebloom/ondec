# Auto Quote

Auto Quote is a built-in template plugin for scaffolding WordPress plugins.
